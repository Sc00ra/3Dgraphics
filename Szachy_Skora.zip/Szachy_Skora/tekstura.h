#include <stdio.h>
#include <windows.h>


#include "gl/glew.h"
#include "GL/freeglut.h"
#include <gl\gl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

GLuint WczytajTeksture(const char *filename);
